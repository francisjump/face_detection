import glob
import math
import os
import time
import re
from statistics import mean
from timeit import default_timer as timer
# To install this module, run:
# python -m pip install Pillow
import matplotlib.pyplot as plt
from azure.cognitiveservices.vision.face import FaceClient
from msrest.authentication import CognitiveServicesCredentials

from PIL import Image
from PIL import ImageDraw
import json
import pandas as pd


def group_images(source_path,frame_name_list, frequency):
    test_image_array = []
    for frame in frame_name_list:
        if int(frame[:-4]) % frequency == 0:
            test_image_array.append(source_path + frame[:-4] + '.jpg')
    test_image_array.sort(key=lambda f: int(re.sub('\D', '', f)))
    print(test_image_array)
    return test_image_array


def sample_rate(source_path,frame_name_list):
    print(
        'How frequent would you like the program to analyze the video?')
    print(
        'The program takes snapshots of the video on a given interval and analysis the snapshots. ')
    print(
        'Analyze more frequently can get more precise results, but will result in longer processing time.')
    while True:
        print('Enter the interval: Analyze once every _ seconds (input a number, e.g., 1) ')
        frequency_seconds = input()
        frequency_frames = float(frequency_seconds) * 30
        print(frequency_seconds)
        print(frequency_frames)
        print('This setup will require at least ')
        print(str(round(
            get_expected_time(frame_name_list, int(frequency_frames), 6),2)) + ' seconds / ' + str(round(
            (get_expected_time(frame_name_list, int(frequency_frames), 6)/ 60),2)) + ' minutes / ' +str(round(
            (get_expected_time(frame_name_list, int(frequency_frames), 6)/ 60/ 60),2))+ ' hours')

        # print('This setup will last for at least ' + str(get_expected_time(frame_name_list, int(frequency_frames), 1800, student_num)))
        print('Confirm the above setup and start the program? (Please input Y to confirm, N to reset the frequency)')
        confirm = input()
        if confirm == 'Y':
            test_image_array = group_images(source_path,frame_name_list, frequency_frames)
            return test_image_array
        else:
            continue


def get_expected_time(test_image_array, frequency, compare_rate):
    frame_per_seconds = 30
    frame_process_time = math.ceil(len(test_image_array) / frequency) / frame_per_seconds
    face_compare_time = math.ceil(len(test_image_array) / frequency) / compare_rate
    free_tier_hits = (math.ceil(len(test_image_array) / frequency) / 20) * 60
    loop_wait = face_compare_time * 60
    expected_time = frame_process_time + face_compare_time + free_tier_hits + loop_wait * 2
    # print(len(test_image_array))
    # print(round(frame_process_time,2))
    # print(round(face_compare_time,2))
    # print(round(free_tier_hits,2))
    # print(round(loop_wait,2))
    # print(round(students_wait,2))
    return expected_time


def source_to_recognized(source_path,dest_path,fig_path,summary_path,file_name):

    if not os.path.exists(dest_path):
        os.mkdir(dest_path)
    if not os.path.exists(summary_path):
        os.makedirs(summary_path)
    if not os.path.exists(fig_path):
        os.makedirs(fig_path)
    # useFont = ImageFont.truetype("arial.ttf", 12)
    credential = json.load(open("./credential.json"))
    # This key will serve all examples in this document.
    KEY = credential["KEY"]
    # This endpoint will be used in all examples in this quickstart.
    ENDPOINT = credential["ENDPOINT"]
    # Create an authenticated FaceClient.
    face_client = FaceClient(ENDPOINT, CognitiveServicesCredentials(KEY))
    '''
    Identify a face against a defined PersonGroup
    '''
    # Group image for testing against
    frame_name_list = os.listdir(source_path)
    if '.DS_Store' in frame_name_list:
        frame_name_list.remove('.DS_Store')
    #print(frame_name_list)

    test_image_array = sample_rate(source_path, frame_name_list)
    overall_stat = []
    count = 0
    summary = pd.DataFrame()
    summary2 = pd.DataFrame()
    compare2 = []
    compare2.append(5)
    test = 1
    for i in range(len(test_image_array)):
        # Wait for 1 minute every 20 recognition for the free plan
        count += 1
        if count > 19:
            print("Waiting for the limit of free plan")
            time.sleep(60)
            count = 0

        image = open(test_image_array[i], 'r+b')
        source_video = 'sourceVideo'
        # Detect faces
        face_ids = []
        # We use detection model 1 to get emotion, recognition model 4 to support quality for recognition attribute.
        faces = face_client.face.detect_with_stream(image, detection_model='detection_01',
                                                    recognition_model='recognition_04', return_face_attributes=['emotion','headPose'],
                                                    return_face_landmarks=True,
                                                    return_face_id=True)

        # We use detection model 3 to get better performance, recognition model 4 to support quality for recognition attribute.
        # faces = face_client.face.detect_with_stream(image, detection_model='detection_03',
        #                                            recognition_model='recognition_04',
        #                                            # return_face_attributes=['emotion','headPose'],
        #                                            return_face_landmarks=True, return_face_attributes=['headPose'],  return_face_id=True)
        image.close()
        emotion_stat = {"anger": [], "contempt": [], "disgust": [], "fear": [], "happiness": [], "neutral": [],
                                     "sadness": [], "surprise": []}
        index = 0
        for f in faces[:]:
            coordinate = pd.DataFrame()
            print(test_image_array[i])
            print(test_image_array[i][test_image_array[i].index('/')+1+len(source_video)+1+len(file_name)+1:-4])
            coordinate["time_index"]=[int(test_image_array[i][test_image_array[i].index('/')+1+len(source_video)+1+len(file_name)+1:-4])]
            coordinate["face_id"] = [f.face_id]

            coordinate["face_position_top"] = [f.face_rectangle.top]
            coordinate["face_position_left"] = [f.face_rectangle.left]
            coordinate["face_position_width"] = [f.face_rectangle.width]
            coordinate["face_position_height"] = [f.face_rectangle.height]

            coordinate["pupil_left_middle_x"] = [f.face_landmarks.pupil_left.x]
            coordinate["pupil_left_middle_y"] = [f.face_landmarks.pupil_left.y]
            coordinate["eye_left_left_x"] = [f.face_landmarks.eye_left_outer.x]
            coordinate["eye_left_left_y"] = [f.face_landmarks.eye_left_outer.y]
            coordinate["eye_left_right_x"] = [f.face_landmarks.eye_left_inner.x]
            coordinate["eye_left_right_y"] = [f.face_landmarks.eye_left_inner.y]
            coordinate["eye_left_top_x"] = [f.face_landmarks.eye_left_top.x]
            coordinate["eye_left_top_y"] = [f.face_landmarks.eye_left_top.y]
            coordinate["eye_left_bottom_x"] = [f.face_landmarks.eye_left_bottom.x]
            coordinate["eye_left_bottom_y"] = [f.face_landmarks.eye_left_bottom.y]
            coordinate["pupil_right_middle_x"] = [f.face_landmarks.pupil_right.x]
            coordinate["pupil_right_middle_y"] = [f.face_landmarks.pupil_right.y]
            coordinate["eye_right_left_x"] = [f.face_landmarks.eye_right_outer.x]
            coordinate["eye_right_left_y"] = [f.face_landmarks.eye_right_outer.y]
            coordinate["eye_right_right_x"] = [f.face_landmarks.eye_right_inner.x]
            coordinate["eye_right_right_y"] = [f.face_landmarks.eye_right_inner.y]
            coordinate["eye_right_top_x"] = [f.face_landmarks.eye_right_top.x]
            coordinate["eye_right_top_y"] = [f.face_landmarks.eye_right_top.y]
            coordinate["eye_right_bottom_x"] = [f.face_landmarks.eye_right_bottom.x]
            coordinate["eye_right_bottom_y"] = [f.face_landmarks.eye_right_bottom.y]
            eye_left_width_x = round(abs(f.face_landmarks.eye_left_outer.x - f.face_landmarks.eye_left_inner.x),
                                     1)
            eye_left_width_y = round(abs(f.face_landmarks.eye_left_top.y - f.face_landmarks.eye_left_bottom.y), 1)
            coordinate["eye_left_width_x"] = [eye_left_width_x]
            coordinate["eye_left_width_y"] = [eye_left_width_y]

            horizontal_index_left = round(
                f.face_landmarks.eye_left_outer.x + f.face_landmarks.eye_left_inner.x - 2 * f.face_landmarks.pupil_left.x,
                1)
            vertical_index_left = round(
                f.face_landmarks.eye_left_top.y + f.face_landmarks.eye_left_bottom.y - 2 * f.face_landmarks.pupil_left.y,
                1)
            horizontal_index_right = round(
                f.face_landmarks.eye_right_outer.x + f.face_landmarks.eye_right_inner.x - 2 * f.face_landmarks.pupil_right.x,
                1)
            vertical_index_right = round(
                f.face_landmarks.eye_right_top.y + f.face_landmarks.eye_right_bottom.y - 2 * f.face_landmarks.pupil_right.y,
                1)

            coordinate["horizontal_index_left"] = [horizontal_index_left]
            coordinate["vertical_index_left"] = [vertical_index_left]
            coordinate["horizontal_index_right"] = [horizontal_index_right]
            coordinate["vertical_index_right"] = [vertical_index_right]

            horizontal_index = round(mean([horizontal_index_left, horizontal_index_right]), 1)
            vertical_index = round(mean([vertical_index_left, vertical_index_right]), 1)
            horizontal_index_percent = round(abs(horizontal_index / eye_left_width_x) * 100, 1)
            vertical_index_percent = round(abs(vertical_index / eye_left_width_y) * 100, 1)

            coordinate["horizontal_index"] = [horizontal_index]
            coordinate["vertical_index"] = [vertical_index]
            coordinate["horizontal_index_percent"] = [horizontal_index_percent]
            coordinate["vertical_index_percent"] = [vertical_index_percent]

            coordinate["mouth_left_x"] = [f.face_landmarks.mouth_left.x]
            coordinate["mouth_left_y"] = [f.face_landmarks.mouth_left.y]
            coordinate["mouth_right_x"] = [f.face_landmarks.mouth_right.x]
            coordinate["mouth_right_y"] = [f.face_landmarks.mouth_right.y]
            coordinate["upper_lip_top_x"] = [f.face_landmarks.upper_lip_top.x]
            coordinate["upper_lip_top_y"] = [f.face_landmarks.upper_lip_top.y]
            coordinate["upper_lip_bottom_x"] = [f.face_landmarks.upper_lip_bottom.x]
            coordinate["upper_lip_bottom_y"] = [f.face_landmarks.upper_lip_bottom.y]
            coordinate["under_lip_top_x"] = [f.face_landmarks.under_lip_top.x]
            coordinate["under_lip_top_y"] = [f.face_landmarks.under_lip_top.y]
            coordinate["under_lip_bottom_x"] = [f.face_landmarks.under_lip_bottom.x]
            coordinate["under_lip_bottom_y"] = [f.face_landmarks.under_lip_bottom.y]

            coordinate["anger"]=[f.face_attributes.emotion.anger]
            coordinate["contempt"] = [f.face_attributes.emotion.contempt]
            coordinate["disgust"] = [f.face_attributes.emotion.disgust]
            coordinate["fear"] = [f.face_attributes.emotion.fear]
            coordinate["happiness"] = [f.face_attributes.emotion.happiness]
            coordinate["neutral"] = [f.face_attributes.emotion.neutral]
            coordinate["sadness"] = [f.face_attributes.emotion.sadness]
            coordinate["surprise"] = [f.face_attributes.emotion.surprise]

            coordinate["head_pose_pitch"] = [f.face_attributes.head_pose.pitch]
            coordinate["head_pose_yaw"] = [f.face_attributes.head_pose.yaw]
            coordinate["head_pose_roll"] = [f.face_attributes.head_pose.roll]
            print(f.face_rectangle.top)
            print(f.face_rectangle.left)
            print(f.face_rectangle.height)
            print(f.face_rectangle.width)
            new_length = len(faces)
            face_removed = False
            image_size = Image.open(test_image_array[i])
            width, height = image_size.size
            separate_width, separate_height, each_row_faces, each_column_faces = get_faces(width, height, new_length)
            face_position = get_face_position(source_path + str(int(
                test_image_array[i][
                test_image_array[i].index('/') + 1 + len(source_video) + 1 + len(file_name) + 1:-4])) + '.jpg',
                                              new_length, f.face_rectangle.top, f.face_rectangle.left)
            print(face_position)
            if face_position >= new_length:
                faces.pop(index)
                print('face remove')
                index -= 1
                face_removed = True
                new_length = len(faces)
                print('new length' + str(len(faces)))

            if not face_removed:
                face_position = get_face_position(source_path+str(int(
                    test_image_array[i][
                    test_image_array[i].index('/') + 1 + len(source_video) + 1 + len(file_name) + 1:-4]))+ '.jpg',
                                                  new_length, f.face_rectangle.top, f.face_rectangle.left)
                coordinate["face_position"] = [face_position]
                if len(faces) >= (each_row_faces * each_column_faces):
                    summary = pd.concat([summary, coordinate])

            index += 1
            emotion_stat["anger"].append(f.face_attributes.emotion.anger)
            emotion_stat["contempt"].append(f.face_attributes.emotion.contempt)
            emotion_stat["disgust"].append(f.face_attributes.emotion.disgust)
            emotion_stat["fear"].append(f.face_attributes.emotion.fear)
            emotion_stat["happiness"].append(f.face_attributes.emotion.happiness)
            emotion_stat["neutral"].append(f.face_attributes.emotion.neutral)
            emotion_stat["sadness"].append(f.face_attributes.emotion.sadness)
            emotion_stat["surprise"].append(f.face_attributes.emotion.surprise)

        print(len(faces))
        print(len(test_image_array))
        compare = 6
        if i != 0 and i % compare == 0:
            compare2.append(int(
                        test_image_array[i][
                        test_image_array[i].index('/') + 1 + len(source_video) + 1 + len(file_name) + 1:-4]))
            test = test + 1
            print('Test:' +  str(test) + str(compare2))
        #     for face_target_path in face_target_list:
        #        print('Target:' + face_target_path)
            time.sleep(60)
            image_test = open(source_path+str(int(
                        test_image_array[i][
                        test_image_array[i].index('/') + 1 + len(source_video) + 1 + len(file_name) + 1:-4]))+ '.jpg', 'r+b')
            # We use detection model 3 to get better performance, recognition model 4 to support quality for recognition attribute.
            face_test = face_client.face.detect_with_stream(image_test, detection_model='detection_03',
                                                  recognition_model='recognition_04',return_face_id=True)

            image_test.close()
            for faceCompare in range(len(faces)):
                print('compared to: Face# ' + faces[faceCompare].face_id)

                face_position = get_face_position(source_path+str(int(
                        test_image_array[i][
                        test_image_array[i].index('/') + 1 + len(source_video) + 1 + len(file_name) + 1:-4]))+ '.jpg',
                                                      len(faces), faces[faceCompare].face_rectangle.top, faces[faceCompare].face_rectangle.left)
                #if faces[faceCompare].face_rectangle.top < 500 and faces[faceCompare].face_rectangle.left < 800:
                #    print("face_relative_position #0")
                #if faces[faceCompare].face_rectangle.top < 500 and faces[faceCompare].face_rectangle.left >= 800:
                #    print("face_relative_position #1")
                #if faces[faceCompare].face_rectangle.top >= 500 and faces[faceCompare].face_rectangle.left < 800:
                #    print("face_relative_position #2")
                # if faces[faceCompare].face_rectangle.top >= 500 and faces[faceCompare].face_rectangle.left >= 800:
                print("new face_relative_position")
                # face_comparision(summary2, face_target_path, face_client, face_position, face_test, faces[faceCompare].face_id)

                start = timer()
                for face in face_test:
                    coordinate2 = pd.DataFrame()
                    if len(compare2) > 1:
                        compare_source = compare2[test-2]
                    else:
                        compare_source = compare2[0]
                    print(source_path+str(compare_source)+'.jpg')

                    face_position_test = get_face_position(source_path+str(compare_source)+'.jpg',
                                                               len(face_test),
                                                               face.face_rectangle.top,
                                                               face.face_rectangle.left)
                    verify_result = face_client.face.verify_face_to_face(faces[faceCompare].face_id, face.face_id)
                    print(faces[faceCompare].face_id)
                     #  print(face)
                    print(face.face_id)
                    print(verify_result.is_identical)
                    print(verify_result.confidence)
                    coordinate2["index"] = [int(
                        test_image_array[i][
                        test_image_array[i].index('/') + 1 + len(source_video) + 1 + len(file_name) + 1:-4])]
                #    coordinate2["compare_file"] = [face_target_path]
                    coordinate2["compare_source"] = [compare_source]

                    coordinate2["face_position"] = [face_position]
                    coordinate2["face_position_test"] = [face_position_test]

                    coordinate2["face_id"] = [faces[faceCompare].face_id]
                    if verify_result.is_identical:
                        coordinate2["is_identical"] = [True]
                    else:
                        coordinate2["is_identical"] = [False]
                    coordinate2["confidence"] = [verify_result.confidence]
                    if face_position == face_position_test:
                        summary2 = pd.concat([summary2, coordinate2])
                end = timer()
                print('verify time ' + str(end - start))
            time.sleep(60)

        if len(faces)==0: # Didn't recognized faces
          emotion_average = {key: 0 for (key, value) in emotion_stat.items()}
        else:
          emotion_average = {key: (sum(value) / len(value)) for (key, value) in emotion_stat.items()}
        overall_stat.append(
            [emotion_average["anger"], emotion_average["contempt"], emotion_average["disgust"], emotion_average["fear"],
             emotion_average["happiness"], emotion_average["neutral"], emotion_average["sadness"],
             emotion_average["surprise"]])
        plt.bar(range(len(emotion_average)), list(emotion_average.values()), tick_label=list(emotion_average.keys()))
        plt.ylim(0, 1)
        plt.savefig(fig_path + test_image_array[i][test_image_array[i].find(source_path) + len(source_path):])
        plt.clf()
        anchorImageIndex = int(
            test_image_array[i][test_image_array[i].index('/')+1+len(source_video)+1+len(file_name)+1:-4])
        img_stat = Image.open(fig_path + test_image_array[i][test_image_array[i].find(source_path) + len(source_path):])
        for j in range(10):
            try:
                img = Image.open(source_path + str(anchorImageIndex + j) + '.jpg')
                img_stat = img_stat.resize((img.width // 4, img.height // 3))
                img.paste(img_stat, (int(img.width * 0.75), int(img.height * 0.67)))
                draw = ImageDraw.Draw(img)
                # draw.text((28, 36), str(face.face_attributes.emotion).replace(',', '\n'), fill=(255, 0, 0), font=useFont)
                for face in faces:
                    # if abs(face.face_landmarks.pupil_left.x - face.face_landmarks.eye_left_inner.x) > 6:
                    #     draw.text((face.face_rectangle.left, face.face_rectangle.top - 20), "Not Concentrated"
                    #               , fill=(255, 0, 0), font=useFont)
                    # else:
                    #     draw.text((face.face_rectangle.left, face.face_rectangle.top - 20), "Concentrated"
                    #               , fill=(0, 0, 255), font=useFont)
                    draw.text((face.face_rectangle.left - 120, face.face_rectangle.top),
                              str(face.face_attributes.emotion).replace(',', '\n'), fill=(255, 0, 0),
                              # font=useFont
                              )
                    draw.rectangle([face.face_rectangle.left, face.face_rectangle.top,
                                    face.face_rectangle.left + face.face_rectangle.width,
                                    face.face_rectangle.top + face.face_rectangle.height],
                                   outline="red")
                    draw.ellipse((face.face_landmarks.pupil_left.x - 5, face.face_landmarks.pupil_left.y - 1,
                                  face.face_landmarks.pupil_left.x + 1, face.face_landmarks.pupil_left.y + 1),
                                 fill="red")
                    draw.ellipse((face.face_landmarks.pupil_right.x - 5, face.face_landmarks.pupil_right.y - 1,
                                  face.face_landmarks.pupil_right.x + 1, face.face_landmarks.pupil_right.y + 1),
                                 fill="red")
                    draw.ellipse((face.face_landmarks.eye_left_top.x - 5, face.face_landmarks.eye_left_top.y - 1,
                                  face.face_landmarks.eye_left_top.x + 1, face.face_landmarks.eye_left_top.y + 1),
                                 fill="blue")
                    draw.ellipse((face.face_landmarks.eye_left_bottom.x - 5, face.face_landmarks.eye_left_bottom.y - 1,
                                  face.face_landmarks.eye_left_bottom.x + 1, face.face_landmarks.eye_left_bottom.y + 1),
                                 fill="blue")
                    draw.ellipse((face.face_landmarks.eye_left_inner.x - 5, face.face_landmarks.eye_left_inner.y - 1,
                                  face.face_landmarks.eye_left_inner.x + 1, face.face_landmarks.eye_left_inner.y + 1),
                                 fill="blue")
                    draw.ellipse((face.face_landmarks.eye_left_outer.x - 5, face.face_landmarks.eye_left_outer.y - 1,
                                  face.face_landmarks.eye_left_outer.x + 1, face.face_landmarks.eye_left_outer.y + 1),
                                 fill="blue")
                    draw.ellipse((face.face_landmarks.eye_right_top.x - 5, face.face_landmarks.eye_right_top.y - 1,
                                  face.face_landmarks.eye_right_top.x + 1, face.face_landmarks.eye_right_top.y + 1),
                                 fill="blue")
                    draw.ellipse(
                        (face.face_landmarks.eye_right_bottom.x - 5, face.face_landmarks.eye_right_bottom.y - 1,
                         face.face_landmarks.eye_right_bottom.x + 1, face.face_landmarks.eye_right_bottom.y + 1),
                        fill="blue")
                    draw.ellipse((face.face_landmarks.eye_right_inner.x - 5, face.face_landmarks.eye_right_inner.y - 1,
                                  face.face_landmarks.eye_right_inner.x + 1, face.face_landmarks.eye_right_inner.y + 1),
                                 fill="blue")
                    draw.ellipse((face.face_landmarks.eye_right_outer.x - 5, face.face_landmarks.eye_right_outer.y - 1,
                                  face.face_landmarks.eye_right_outer.x + 1, face.face_landmarks.eye_right_outer.y + 1),
                                 fill="blue")

                img.save(dest_path + str(anchorImageIndex + j) + '.jpg')

            except FileNotFoundError:
                break
    printSummary = []
    for line in overall_stat:
        printSummary.append(','.join([str(i) for i in line]))
    print('\n'.join(printSummary))
    print(summary)
    summary=summary.sort_values(by=['time_index','face_position'], ascending=[True, True])
    # summary = summary.drop([summary.columns[0]], axis=1)
    summary.to_csv(summary_path+"summary.csv", index = False)
    summary2.to_csv(summary_path + "summary_face_compare.csv", index = False)
    time.sleep(60)


def get_faces(width,height,face_length):
    each_row_faces = math.ceil(math.sqrt(face_length))
    each_column_faces = math.ceil(math.sqrt(face_length))
    print(each_row_faces)
    print(each_column_faces)
    separate_width = width / each_row_faces
    separate_height = height / each_column_faces
    return separate_width, separate_height, each_row_faces, each_column_faces


def get_face_measurement(separate_width, separate_height, each_row_faces, each_column_faces):
    row = []
    for i in range(each_row_faces):
        column = []
        for j in range(each_column_faces):
            column.append(
                [separate_width * j, separate_width * (j + 1), separate_height * i, separate_height * (i + 1)])
        row.append(column)
    return row


def get_face_position(source_path, face_length, top, left):
    crop = Image.open(source_path)
    width, height = crop.size
    separate_width, separate_height, each_row_faces, each_column_faces = get_faces(width, height, face_length)
    row = get_face_measurement(separate_width, separate_height, each_row_faces, each_column_faces)
    print(row)
    face_position = 0
    for i in range(each_row_faces):
        for j in range(each_column_faces):
            #print('position#' + str(left >= row[i][j][0]))
            #print('position#' + str(left < row[i][j][1]))
            #print('position#' + str(top >= row[i][j][2]))
            #print('position#' + str(top < row[i][j][3]))
            if left >= row[i][j][0] and left <= row[i][j][1] and top >= row[i][j][2] and top <= row[i][j][3]:
                print('position#'+ str(face_position))
                return face_position
            face_position += 1


