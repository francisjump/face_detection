import cv2, os

def getVideo(dest_path):
    print('Enter the video name:')
    #url = "https://youtu.be/ZSzrNp4_1zU"
    video_title = input()
    print('Proceed to split the video into frames: (It may take some time. Please wait.)')
    sourceVideoToFrame('./sourceVideo/'+ video_title +'.mp4', dest_path + video_title + '/')
    # print(dest_path + video.title + '/')
    return video_title


def sourceVideoToFrame(url, dest_path):
    vidcap = cv2.VideoCapture(url)
    success, image = vidcap.read()
    count = 0
    if not os.path.exists(dest_path):
        os.mkdir(dest_path)
    while success:
        cv2.imwrite(dest_path + "%d.jpg" % count, image)  # save frame as JPEG file
        success, image = vidcap.read()
        count += 1
    print('done')
    print('Read total frames: ', count)
