import joblib
import pandas as pd
from sklearn.preprocessing import StandardScaler

# read the csv file using Pandas
df = pd.read_csv("./summary.csv")
# set specific columns of csv file as X
list_of_columns = ['horizontal_index', 'vertical_index', 'anger', 'contempt', 'disgust', 'fear', 'happiness', 'neutral', 'sadness', 'surprise', 'head_pose_pitch', 'head_pose_yaw', 'head_pose_roll']
X = df[list_of_columns]
print(X)
print(len(X))

random_forest_joblib = joblib.load('./model/random_forest.pkl')

random_forest_predict = random_forest_joblib.predict(X)

print(random_forest_predict)

svm_joblib = joblib.load('./model/svm.pkl')

svm_predict = svm_joblib.predict(X)

print(svm_predict)

k_neighbors_joblib = joblib.load('./model/k_neighbors.pkl')

k_neighbors_predict = k_neighbors_joblib.predict(X)

print(k_neighbors_predict)

scaler = StandardScaler()
scaler.fit(X)

X_transform = scaler.transform(X)
mlp_joblib = joblib.load('./model/mlp.pkl')
mlp_predict = mlp_joblib.predict(X_transform)

print(mlp_predict)

summary = pd.DataFrame()
for predict in range(len(random_forest_predict)):
    coordinate = pd.DataFrame()
    row_ID = predict + 2
    coordinate["row_ID"] = [row_ID]
    horizontal_index = X['horizontal_index'][predict]
    coordinate["horizontal_index"] = [horizontal_index]
    vertical_index = X['vertical_index'][predict]
    coordinate["vertical_index"] = [vertical_index]
    head_pose_pitch = X['head_pose_pitch'][predict]
    coordinate["head_pose_pitch"] = [head_pose_pitch]
    head_pose_yaw = X['head_pose_yaw'][predict]
    coordinate["head_pose_yaw"] = [head_pose_yaw]
    head_pose_roll = X['head_pose_roll'][predict]
    coordinate["head_pose_roll"] = [head_pose_roll]

    coordinate["random_forest_predict"] = [random_forest_predict[predict]]
    coordinate["svm_predict"] = [svm_predict[predict]]
    coordinate["k_neighbors_predict"] = [k_neighbors_predict[predict]]
    coordinate["mlp_predict"] = [mlp_predict[predict]]
    score = 0
    if random_forest_predict[predict] == 'yes':
        score += 2
    if svm_predict[predict] == 'yes':
        score += 1
    if k_neighbors_predict[predict] == 'yes':
        score += 1
    if mlp_predict[predict] == 'yes':
        score += 2
    coordinate["score"] = [score]

    summary = pd.concat([summary, coordinate])

summary.to_csv("./predict.csv")
